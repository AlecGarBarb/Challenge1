package com.example.alecyeric.challenge1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button math;
    private Button art;
    private Button geo;
    private Button history;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        math = (Button) findViewById(R.id.mathButton);
        art = (Button) findViewById(R.id.artButton);
        geo = (Button) findViewById(R.id.geoButton);
        history = (Button) findViewById(R.id.historyButton);
    }

    public void facts(View view) {
        switch (view.getId()) {
            case R.id.mathButton:
                Intent intent = new Intent(this, Mate.class);
                startActivity(intent);
                break;

            case R.id.artButton:
                Intent intent2 = new Intent(this, Art.class);
                startActivity(intent2);
                break;

            case R.id.geoButton:
                Intent intent3 = new Intent(this, Geo.class);
                startActivity(intent3);
                break;

            case R.id.historyButton:
                Intent intent4 = new Intent(this, History.class);
                startActivity(intent4);
                break;
        }
    }




}
