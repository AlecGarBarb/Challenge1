package com.example.alecyeric.challenge1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;



public class History extends AppCompatActivity {
    private final String JSON_URL_History = "https://www.json-generator.com/api/json/get/bUrtHfwbSa?indent=2" ;
    private JsonObjectRequest requestHistory;
    private JSONObject objectHistory;
    private TextView txtviewHistory;
    private int randomNumber;
    private Button ref;
    int num=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        ref = (Button) findViewById(R.id.next);
        txtviewHistory = findViewById(R.id.random);
        jsonIntento3();


    }
    private void jsonIntento3(){
        RequestQueue queue3 = Volley.newRequestQueue(this);
        //txtviewHistory.setText("Entraste.");
        requestHistory = new JsonObjectRequest(Request.Method.GET, JSON_URL_History, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                txtviewHistory.setText(response.toString());
                objectHistory= response;
                try{
                    txtviewHistory.setText(response.getString("1"));
                }catch(JSONException jsonException){
                    jsonException.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                txtviewHistory.setText("no Response Error");
            }
        });
        queue3.add(requestHistory);
    }



    public void next(View view){
        switch (view.getId()) {
            case R.id.next:
                num=num+1;
            case R.id.again:
                num=1;
        }
        String val = String.valueOf(num);
        try {
            txtviewHistory.setText(objectHistory.getString(val));
        }
        catch (JSONException jsonException) {
            txtviewHistory.setText("Error en catch");
            jsonException.printStackTrace();
        }catch(NullPointerException exception){
            txtviewHistory.setText("no hay objeto cargado");
        }

    }
}