package com.example.alecyeric.challenge1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Random;

public class Art extends AppCompatActivity {


    private final String JSON_URL = "http://www.json-generator.com/api/json/get/bQLVEodiCq?indent=2" ;


    private JsonArrayRequest requestArray;


    private JSONArray array;

    private TextView txtview2;


    public Button ref2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_art);

        ref2 = findViewById(R.id.buttonART);


        txtview2 = findViewById(R.id.txtART);

        txtview2.setText("Art.");

        jsonIntento2();
    }
    private void jsonIntento2(){
        RequestQueue queue2 = Volley.newRequestQueue(this);
        //txtview2.setText("Entraste.");
        requestArray = new JsonArrayRequest(
                Request.Method.GET,
                JSON_URL,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Do something with response
                        txtview2.setText(response.toString());


                        array = response;

                        // Process the JSON
                        try{
                            // Loop through the array elements
                            JSONObject student = response.getJSONObject(1);

                        }catch(JSONException jsonException){
                            //txtview.setText("Error en catch");
                            jsonException.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        // Do something when error occurred
                        txtview2.setText("Error response");
                    }
                }
        );
        queue2.add(requestArray);


    }


    public void refresh(View view){
        switch (view.getId()) {
            case R.id.buttonART:
                Random rand = new Random();
                int num = rand.nextInt(99);

                String cosito = String.valueOf(num);


                try {
                    String imageURL = array.getJSONObject(num).getString("imageURL");
                    String description = array.getJSONObject(num).getString("description");

                    txtview2.setText("URL de imagen: "+ imageURL +"\n descripcion: " + description);

                    Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(imageURL));
                    startActivity(myIntent);


                } catch (JSONException jsonException) {
                    txtview2.setText("Error en catch");
                    jsonException.printStackTrace();
                }
        }
    }
}
