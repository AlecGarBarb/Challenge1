package com.example.alecyeric.challenge1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

import com.android.volley.Request;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;






public class Mate extends AppCompatActivity {

    private final String JSON_URL = "http://numbersapi.com/1..100" ;

    private JsonArrayRequest request;

    private JsonObjectRequest requestobj;

    private JSONObject object;

    private JSONArray array;

    private TextView txtview;

    public Button ref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mate);


        ref = findViewById(R.id.Refresh);


        txtview = findViewById(R.id.random);


        jsonIntento23();



    }



    private void jsonIntento23(){
        RequestQueue queue = Volley.newRequestQueue(this);

        //txtview.setText("Entraste.");

        requestobj = new JsonObjectRequest
                (Request.Method.GET, JSON_URL, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        txtview.setText(response.toString());

                        object= response;

                        try {
                            txtview.setText(object.getString("1").toString());


                            //Toast.makeText(getApplicationContext(), cosito, Toast.LENGTH_LONG).show();

                            //txtview.setText(response.toString());
                        }catch(JSONException jsonException){
                            txtview.setText("Error en catch");
                            jsonException.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        txtview.setText("No hay respuesta del server");

                    }
                });
        queue.add(requestobj);
    }


    public void refresh(View view){
        switch (view.getId()) {
            case R.id.Refresh:
                Random rand = new Random();
                int num = rand.nextInt(99);

                String cosito = String.valueOf(num);


                try {
                    txtview.setText(object.getString(cosito));


                } catch (JSONException jsonException) {
                    txtview.setText("Error en catch");
                    jsonException.printStackTrace();
                } catch(NullPointerException exception){
                    txtview.setText("no hay objeto");
                }
        }
    }



}
